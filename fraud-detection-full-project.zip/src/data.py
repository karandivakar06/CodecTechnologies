# Implementation available in textdoc
