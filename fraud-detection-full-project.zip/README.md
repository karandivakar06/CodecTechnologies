# Fraud Detection System

This project detects fraudulent transactions using:
- Supervised classification with SMOTE
- Isolation Forest anomaly detection

## Quickstart
```bash
pip install -r requirements.txt
python main.py --generate_synthetic --rows 10000
```
